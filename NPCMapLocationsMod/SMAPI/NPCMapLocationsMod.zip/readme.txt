Go to the directory containing "StardewModdingAPI" and place "NPCMapLocations" in the "Mods" directory 

Go to {Directory containing StardewValley.exe}\Content\Characters and place "NPCMarkers"